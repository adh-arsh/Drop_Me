package com.drop_me

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
